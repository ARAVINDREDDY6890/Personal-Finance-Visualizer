const TransactionList = ({ transactions, onDeleteTransaction }) => {
  return (
    <ul>
      {transactions.map((transaction) => (
        <li key={transaction._id}>
          {transaction.amount} - {transaction.date} - {transaction.description}
          <button onClick={() => onDeleteTransaction(transaction._id)}>Delete</button>
        </li>
      ))}
    </ul>
  );
};

export default TransactionList;