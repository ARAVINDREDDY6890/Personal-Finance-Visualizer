import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const MonthlyExpensesChart = ({ transactions }) => {
  const data = transactions.reduce((acc, transaction) => {
    const month = new Date(transaction.date).toLocaleString('default', { month: 'short' });
    const existing = acc.find((item) => item.month === month);
    if (existing) {
      existing.amount += transaction.amount;
    } else {
      acc.push({ month, amount: transaction.amount });
    }
    return acc;
  }, []);

  return (
    <BarChart width={600} height={300} data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="month" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Bar dataKey="amount" fill="#8884d8" />
    </BarChart>
  );
};

export default MonthlyExpensesChart;