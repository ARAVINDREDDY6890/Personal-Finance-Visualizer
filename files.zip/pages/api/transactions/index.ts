import { NextApiRequest, NextApiResponse } from 'next';
import clientPromise from '../../../lib/mongodb';
import { ObjectId } from 'mongodb';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const client = await clientPromise;
  const db = client.db('personal-finance');
  const collection = db.collection('transactions');

  switch (req.method) {
    case 'GET':
      const transactions = await collection.find({}).toArray();
      res.json(transactions);
      break;
    case 'POST':
      const newTransaction = req.body;
      await collection.insertOne(newTransaction);
      res.status(201).json(newTransaction);
      break;
    case 'PUT':
      const { id, ...updateData } = req.body;
      await collection.updateOne({ _id: new ObjectId(id) }, { $set: updateData });
      res.status(200).json(updateData);
      break;
    case 'DELETE':
      const { id: deleteId } = req.body;
      await collection.deleteOne({ _id: new ObjectId(deleteId) });
      res.status(200).json({ message: 'Transaction deleted' });
      break;
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PUT', 'DELETE']);
      res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}